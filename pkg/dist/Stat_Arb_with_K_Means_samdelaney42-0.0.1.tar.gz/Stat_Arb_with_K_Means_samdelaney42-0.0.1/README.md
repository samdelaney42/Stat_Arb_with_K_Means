# K_Means

In this project I aim to re-create the unsupervised machine learning k-means clustering technique with random and plusplus initialization methods, then use the principals of this class in a stat arb trading model to find non-traditional pairs.

